import React, { useState, useEffect, useCallback } from 'react';
import { Cookie, ShoppingBag, Zap, TrendingUp, ShoppingCart, Settings, Save, Star, Target, Clock } from 'lucide-react';

interface GameState {
  cookies: number;
  clickValue: number;
  doubleClicksRemaining: number;
  autoClickerCount: number;
  clickMultiplier: number;
  totalClicks: number;
  achievements: string[];
}

interface Upgrade {
  id: string;
  name: string;
  description: string;
  cost: number;
  icon: React.ReactNode;
  type: 'doubleClick' | 'autoClicker' | 'multiplier' | 'clickPower';
  value: number;
}

const GamePage: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>({
    cookies: 0,
    clickValue: 5,
    doubleClicksRemaining: 0,
    autoClickerCount: 0,
    clickMultiplier: 1,
    totalClicks: 0,
    achievements: []
  });

  const [showShop, setShowShop] = useState<boolean>(false);
  const [clickEffects, setClickEffects] = useState<Array<{ id: number; points: number; x: number; y: number }>>([]);
  const [cookieScale, setCookieScale] = useState<number>(1);

  const upgrades: Upgrade[] = [
    {
      id: 'doubleClick',
      name: 'Double Click Power',
      description: 'Activate double-click mode for 23 clicks! Each click will give you double the normal points.',
      cost: 500,
      icon: <Zap className="w-6 h-6" />,
      type: 'doubleClick',
      value: 23
    },
    {
      id: 'autoClicker',
      name: 'Auto Clicker',
      description: 'Automatically clicks the cookie once per second. Cost increases with each purchase.',
      cost: Math.floor(100 * Math.pow(1.15, gameState.autoClickerCount)),
      icon: <Target className="w-6 h-6" />,
      type: 'autoClicker',
      value: 1
    },
    {
      id: 'clickPower',
      name: 'Click Power Boost',
      description: 'Permanently increase your click value by 5 points per click.',
      cost: 1000,
      icon: <Star className="w-6 h-6" />,
      type: 'clickPower',
      value: 5
    },
    {
      id: 'multiplier',
      name: 'Cookie Multiplier',
      description: 'Multiply all cookie gains by 1.5x. Stacks with other bonuses!',
      cost: 2000,
      icon: <TrendingUp className="w-6 h-6" />,
      type: 'multiplier',
      value: 1.5
    }
  ];

  // Auto clicker effect
  useEffect(() => {
    if (gameState.autoClickerCount > 0) {
      const interval = setInterval(() => {
        setGameState(prev => ({
          ...prev,
          cookies: prev.cookies + (prev.autoClickerCount * prev.clickMultiplier)
        }));
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [gameState.autoClickerCount, gameState.clickMultiplier]);

  // Save game state to localStorage
  useEffect(() => {
    localStorage.setItem('cookieClickerGame', JSON.stringify(gameState));
  }, [gameState]);

  // Load game state from localStorage
  useEffect(() => {
    const savedGame = localStorage.getItem('cookieClickerGame');
    if (savedGame) {
      try {
        const parsedGame = JSON.parse(savedGame);
        setGameState(parsedGame);
      } catch (error) {
        console.error('Failed to load saved game:', error);
      }
    }
  }, []);

  const handleCookieClick = useCallback((event: React.MouseEvent) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    let points = gameState.clickValue;
    
    // Apply double click bonus
    if (gameState.doubleClicksRemaining > 0) {
      points *= 2;
    }
    
    // Apply multiplier
    points = Math.floor(points * gameState.clickMultiplier);

    setGameState(prev => ({
      ...prev,
      cookies: prev.cookies + points,
      doubleClicksRemaining: prev.doubleClicksRemaining > 0 ? prev.doubleClicksRemaining - 1 : 0,
      totalClicks: prev.totalClicks + 1
    }));

    // Visual feedback
    setCookieScale(1.1);
    setTimeout(() => setCookieScale(1), 150);

    // Add click effect
    const effectId = Date.now();
    setClickEffects(prev => [...prev, { id: effectId, points, x, y }]);
    setTimeout(() => {
      setClickEffects(prev => prev.filter(effect => effect.id !== effectId));
    }, 1000);
  }, [gameState.clickValue, gameState.doubleClicksRemaining, gameState.clickMultiplier]);

  const purchaseUpgrade = useCallback((upgrade: Upgrade) => {
    if (gameState.cookies >= upgrade.cost) {
      setGameState(prev => {
        const newState = { ...prev, cookies: prev.cookies - upgrade.cost };
        
        switch (upgrade.type) {
          case 'doubleClick':
            newState.doubleClicksRemaining += upgrade.value;
            break;
          case 'autoClicker':
            newState.autoClickerCount += upgrade.value;
            break;
          case 'clickPower':
            newState.clickValue += upgrade.value;
            break;
          case 'multiplier':
            newState.clickMultiplier *= upgrade.value;
            break;
        }
        
        return newState;
      });
    }
  }, [gameState.cookies]);

  const saveGame = useCallback(() => {
    localStorage.setItem('cookieClickerGame', JSON.stringify(gameState));
    alert('Game saved successfully!');
  }, [gameState]);

  const resetGame = useCallback(() => {
    if (window.confirm('Are you sure you want to reset your game? This cannot be undone!')) {
      const initialState: GameState = {
        cookies: 0,
        clickValue: 5,
        doubleClicksRemaining: 0,
        autoClickerCount: 0,
        clickMultiplier: 1,
        totalClicks: 0,
        achievements: []
      };
      setGameState(initialState);
      localStorage.removeItem('cookieClickerGame');
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-2">
            <Cookie className="w-8 h-8 text-amber-600" />
            <span className="text-xl font-bold text-gray-900">Cookie Clicker Pro</span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#" className="text-gray-700 hover:text-amber-600 font-medium transition-colors">Game</a>
            <button 
              onClick={() => setShowShop(!showShop)}
              className="text-gray-700 hover:text-amber-600 font-medium transition-colors"
            >
              Shop
            </button>
            <a href="#" className="text-gray-700 hover:text-amber-600 font-medium transition-colors">Achievements</a>
            <a href="#" className="text-gray-700 hover:text-amber-600 font-medium transition-colors">Leaderboard</a>
          </nav>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-amber-50 px-3 py-2 rounded-lg">
              <Cookie className="w-4 h-4 text-amber-600" />
              <span className="font-bold text-amber-800">{Math.floor(gameState.cookies).toLocaleString()}</span>
            </div>
            <button 
              onClick={resetGame}
              className="text-gray-700 hover:text-amber-600 transition-colors"
            >
              <Settings className="w-5 h-5" />
            </button>
            <button 
              onClick={saveGame}
              className="bg-amber-600 hover:bg-amber-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Game
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Game Area */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-lg p-8 text-center">
              <div className="mb-6">
                <h1 className="text-4xl font-bold text-gray-900 mb-2">Cookie Clicker Simulator</h1>
                <p className="text-gray-600">Click the cookie to earn points and build your cookie empire!</p>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                <div className="bg-amber-50 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-amber-600">{Math.floor(gameState.cookies).toLocaleString()}</div>
                  <div className="text-sm text-gray-600">Total Cookies</div>
                </div>
                <div className="bg-orange-50 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">{Math.floor(gameState.clickValue * gameState.clickMultiplier)}</div>
                  <div className="text-sm text-gray-600">Per Click</div>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{gameState.autoClickerCount}</div>
                  <div className="text-sm text-gray-600">Auto Clickers</div>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{gameState.totalClicks.toLocaleString()}</div>
                  <div className="text-sm text-gray-600">Total Clicks</div>
                </div>
              </div>

              {/* Cookie */}
              <div className="relative mb-6">
                <div 
                  className="relative w-64 h-64 mx-auto cursor-pointer select-none"
                  onClick={handleCookieClick}
                >
                  <img
                    src="https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=256&h=256&fit=crop&crop=center"
                    alt="Cookie"
                    className="w-full h-full rounded-full object-cover border-8 border-amber-400 shadow-2xl hover:shadow-amber-400/50 transition-all duration-200"
                    style={{ transform: `scale(${cookieScale})` }}
                  />
                  
                  {/* Click Effects */}
                  {clickEffects.map(effect => (
                    <div
                      key={effect.id}
                      className="absolute pointer-events-none animate-bounce text-2xl font-bold text-amber-600 z-10"
                      style={{
                        left: effect.x,
                        top: effect.y,
                        animation: 'fadeUpAndOut 1s ease-out forwards'
                      }}
                    >
                      +{effect.points}
                    </div>
                  ))}
                </div>

                {/* Double Click Indicator */}
                {gameState.doubleClicksRemaining > 0 && (
                  <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-yellow-400 text-gray-900 px-4 py-2 rounded-full font-bold animate-pulse">
                    <Clock className="w-4 h-4 inline mr-2" />
                    Double Clicks: {gameState.doubleClicksRemaining}
                  </div>
                )}
              </div>

              <button
                onClick={handleCookieClick}
                className="bg-amber-600 hover:bg-amber-700 text-white font-semibold py-3 px-6 rounded-lg flex items-center gap-2 transition-colors mx-auto"
              >
                <Cookie className="w-5 h-5" />
                Click Cookie (+{Math.floor(gameState.clickValue * gameState.clickMultiplier * (gameState.doubleClicksRemaining > 0 ? 2 : 1))})
              </button>
            </div>
          </div>

          {/* Shop Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-center gap-2 mb-6">
                <ShoppingBag className="w-6 h-6 text-amber-600" />
                <h2 className="text-2xl font-bold text-gray-900">Shop</h2>
              </div>

              <div className="space-y-4">
                {upgrades.map(upgrade => {
                  const canAfford = gameState.cookies >= upgrade.cost;
                  const updatedCost = upgrade.type === 'autoClicker' 
                    ? Math.floor(100 * Math.pow(1.15, gameState.autoClickerCount))
                    : upgrade.cost;

                  return (
                    <div key={upgrade.id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                      <div className="flex items-start gap-3 mb-3">
                        <div className="text-amber-600">
                          {upgrade.icon}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-bold text-gray-900">{upgrade.name}</h3>
                          <p className="text-sm text-gray-600 mt-1">{upgrade.description}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-gray-900">
                          {updatedCost.toLocaleString()} 🍪
                        </span>
                        <button
                          onClick={() => purchaseUpgrade({ ...upgrade, cost: updatedCost })}
                          disabled={!canAfford}
                          className={`px-4 py-2 rounded-lg font-semibold transition-colors flex items-center gap-2 ${
                            canAfford
                              ? 'bg-amber-600 hover:bg-amber-700 text-white'
                              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                          }`}
                        >
                          <ShoppingCart className="w-4 h-4" />
                          {canAfford ? 'Buy' : 'Need More'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes fadeUpAndOut {
          0% {
            opacity: 1;
            transform: translateY(0);
          }
          100% {
            opacity: 0;
            transform: translateY(-50px);
          }
        }
      `}</style>
    </div>
  );
};

export default GamePage;
